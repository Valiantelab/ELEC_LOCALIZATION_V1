function Indices_To_Native
% Converting the electrode positions from indices to the native space for projection onto the cortex.

data.Name=spm_select(1,'image','select resliced MRI image for electrodes');
data.Struct=spm_vol(data.Name);
[dataMat.elecmatrix]=spm_select(1,'mat','select the .mat file with electrode positions')
load([dataMat.elecmatrix])
els_ind = elecmatrix;

elec_orig = (els_ind/inv(data.Struct.mat(1:3,1:3)'))+repmat(data.Struct.mat(1:3,4),1,size(els_ind,1))';

[dataMat.elecmatrix]=spm_select(1,'mat','select the .mat file with electrode positions');
load([dataMat.elecmatrix]);

elec_shft = (elecmatrix/inv(data.Struct.mat(1:3,1:3)'))+repmat(data.Struct.mat(1:3,4),1,size(els_ind,1))';
% To get back to the indices from the native space.
elecmatrix=round((els_ind-repmat(data.Struct.mat(1:3,4),1,size(els_ind,1))')*inv(data.Struct.mat(1:3,1:3)'));

clear els_ind
outputfile = spm_select(1,'dir','select the directory where you want to save the .mat file');
outputfile = strcat(outputfile, '\Indices_to_Native')

save(outputfile,'elecmatrix');