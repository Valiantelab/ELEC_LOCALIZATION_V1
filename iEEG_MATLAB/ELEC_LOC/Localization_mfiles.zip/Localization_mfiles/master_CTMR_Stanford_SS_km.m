%% MANUAL COREGISTRATION CT to MR
%
% This manual explains how to co-register the post-operative CT scan of a 
% patient to the corresponding pre-operative MRI scan.  This procedure will
% output coordinates in the indivdual headspace of the patient that are
% corrected for the brainshift by projecting lateral electrodes to the 
% individual surface (<http://www.ncbi.nlm.nih.gov/pubmed/19836416 Hermes 
% et al. 2010>).  Ventral and interhemispheric coordinates will not be 
% projected.  These coordinates will also be converted to MNI space for
% inter-subject comparison.  The m-file version of the manual can be found
% <http://www.mathworks.com here> .
%
% *Needed software:*
%
% * Matlab
% * (<http://www.fil.ion.ucl.ac.uk/spm/software/download.html SPM12>)
% * optionally: (<http://fsl.fmrib.ox.ac.uk/fsl/fslwiki/FslInstallation
% FSL>), (<http://bioimagesuite.yale.edu/ BioImageSuite>)

%% 1. Preparation
%
% For most of the steps, simply run the individual sections. If the SPM GUI
% is needed, it will be indicated.
%
% * Create a folder for the co-registration (e.g. coregistration)
% * Create a subfolder called "script"
% * Download all CTMR m-files <http://www.mathworks.com here> to the script
% folder.
% * Create a subfolder in the main folder with the patient's ID.
% * Download the patient's CT and MRI and put them in this subfolder
% * Add SPM12 and the CTMR m-files to your path, e.g.:
% 
%   addpath /Users/kmuesch/Documents/Matlab' Files'/spm12/;
%   addpath /Users/kmuesch/Desktop/coregistration/script/;
%
% * Open the GUI because you will need it throughout this manual.
%
%   spm
%
% * Specify input and output directories. The outputdir should be the
% patient ID subfolder.
% * Have the patient's schematic handy.
% * Have the <http://www.mathworks.com Manual> handy.

    outputdir = spm_select(1,'dir','Select the directory to save all the files');
    cd(outputdir);

%% 2. DICOM to NIFTI Conversion
%
% *2.1 DICOM Import*
%
% In the SPM GUI, choose "DICOM Import" (bottom right panel). Select the
% DICOM files and the output directory. You need to do that for both the CT
% and MR scans.
%
% *2.2 Renaming Files*
%
% Rename the just created CT and MR (e.g. TWH#_CT.nii and TWH#_MR.nii) 
% files. More than one file might have been created. The correct one is the
% one with the biggest file size for each of the CT and MR. You can also
% use SPM's "Check Reg" (lowest panel middle) to check the images.
%
% *2.3 Bring images to same coordinate system*
%  
% * Open the CT scan using "Check Reg"
% * Set the crosshairs approximately to the middle of the AC-PC line
% * Right click on image. Choose "Reorient image(s) / Set origin to 
% crosshair". Choose the same image when prompted. You don't need the
% transformation matrix.
% * Open MR and CT scan using "Check Reg" to ensure that orientation of
% both images approximately align
% * If scans appear rotated >15 degrees from each other, you need to rotate
% the CT (right click on the image; "Reorient image(s) / current image")
% until they are within 15 degrees of each other because otherwise the 
% co-registration in SPM wouldn't work.
%
% If you want to use FSL: translate the CT to the same coordinate space as 
% the MR by doing a linear transformation in FLIRT.

%% 3. Coregister and Reslice CT, Segment MR
% 
% *3.1 Coregister (Estimate & Reslice) CT to MR*
%
% Use the SPM GUI for this step ("Coregister - Estimate & Reslice" in the 
% top left). Specify the two .nii files as input and choose "Trilinear" as
% the Interpolation under Reslice Options. Check the result of the 
% co-registration by using "Check Reg" and click on several landmarks to 
% make sure that they align.
% 
% * reference image = MR
% * source/moved image = CT.
% * interpolation = Trilinear.
%
% *3.2 Segmentation of the anatomical MRI*
%
% Use the SPM GUI for this step ("Segment" in the top right). Select the
% original MR (instead of the resliced rMR, no prefix) under data.

%% 4. Generate Brain Surface
%
% Uses |get_mask_V1(subject, degree of smoothing, threshold)|. The defaults 
% should work. You need to specify:
%
% * the patient's name (e.g. TWH#)
% * the gray matter image (e.g. c1TWH#_MR.nii)
% * the white matter image (e.g. c2TWH#_MR.nii)
% * output directory (same as outputdir)
%
% Use the GUI to check the result with Check Reg" (GUI lowest panel in the 
% middle):
%
% * Select the original MR (without any prefixes).
% * Right click on the image. Choose "Overlay / Add coloured image / local"
% * Select the mask you just created (e.g. TWH#_surface_1_6_01.img);
% * Choose a color for the display (e.g. red). The mask you just created, 
% should nicely surround the gray matter. If not, check the segmentation.

prompt={'Please enter the subject''s name:'};
title= 'Subject name'; 
name = inputdlg(prompt,title);

get_mask_V1(name{1}, 6,0.1);

%% 5. Select Electrodes in CT
%
% Check out "manual ctmr gui_V2.pdf", page 2, for further instructions.
% View result. Save image as a two file Nifti (hdr, img).\
% 
% Use the rTWH#_CT.nii here.
%
% If you want to use BioImageSuite to get the electrode coordinates, skip 
% steps 5 and 6.

ctmr;

%% 6. Sort & Number Unprojected Electrodes
%
% This step needs to be done separately for each grid or strip because 4x4
% and 2x4 grids and 1xN grids will be projected (i) in a different way and
% (ii) individually.
%
% It loads the img file with the electrodes from step 5. It will save each
% grid / strip as electrodes_loc#.
% 
% Look at the Manual for detailed instructions.

sortElectrodes;

%% 7. Project Electrodes on Surface
%
% Uses |[out_els,out_els_ind]=electrodes2surf(subject, local norm index,
% checkdistance, elecselection)|. This section will project the electrodes 
% to the surface, unless they are closer than 3 mm to the surface. If you
% rather not project certain electrodes (e.g. interhemispheric ones), skip
% them in this step.
%
% You'll need to specify:
% 
% * patient ID, if not yet done already (e.g. TWH3#)
% * number of electrode configurations (i.e. total number of different
% grids and strips created above) because the projection is done 
% differently for grids and strips; it will loop across these electrode
% configurations
% * select .mat file with electrode positions
% * select image with gray matter surface created in step 4
% * select original MRI
% * for each configuration enter: 1 = 4x4grid, 2 = 2x4 grid, 3 = strip
% * for each configuration enter: first and last electrode numbers
%
% Output is saved as TWH#_electrodesOnsurfaceFilenumber_localNormIndex.

% enter patient ID
if exist('name','var') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end

% number of electrode configurations
prompt2={'Please enter total number of different grids and strips'};
title2= 'Number of electrode configuration'; 
numberOfConfigurations = inputdlg(prompt2,title2);
numberOfConfigurations = str2double(numberOfConfigurations{1});

% select files
[data.elecName]=spm_select(1,'mat','select .mat file with electrode positions');
[data.gsName]=spm_select(1,'image','select image with gray matter surface');
[data.mrName]=spm_select(1,'image','select MRI image for electrodes');

for i = 1:numberOfConfigurations
    prompt3={'Please enter 1 for grid, 2 for 2XN strip, 3 for 1xN strip'};
    title3= 'Electrode configuration'; 
    configuration = inputdlg(prompt3,title3);

    prompt4={'Please enter first electrode number in this configuration', 'Please enter last electrode number in this configuration'};
    title4= 'Electrode configuration numbering'; 
    configurationNumber = inputdlg(prompt4,title4);
        
    if configuration{1} == '1'
        [out_els,out_els_ind]=electrodes2surf(name{1},5,1,str2double(configurationNumber{1}):str2double(configurationNumber{2}), data.elecName, data.gsName, data.mrName);
    elseif configuration{1} == '2'
        [out_els,out_els_ind]=electrodes2surf(name{1},4,1,str2double(configurationNumber{1}):str2double(configurationNumber{2}), data.elecName, data.gsName, data.mrName);
    elseif configuration{1} == '3'
        [out_els,out_els_ind]=electrodes2surf(name{1},0,2,str2double(configurationNumber{1}):str2double(configurationNumber{2}), data.elecName, data.gsName, data.mrName);
    end
end

%% 8. Combine Electrode Files and Create a Nifti
%
% load all projected electrodes:
% electrodes are saved as out_els

% Enter subject ID
if exist('name','var') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end

% For the first electrode file
[data.elecName]=spm_select(1,'mat','select .mat first file with electrode positions');
load([data.elecName])

%load('./data/name_electrodesOnsurface1_5.mat');
elecmatrix=out_els;

for i = 1:(numberOfConfigurations - 1)
    % For all additional electrode files
    [data.elecName]=spm_select(1,'mat','select the next .mat file with electrode positions');
    load([data.elecName])

    %load('./data/name_electrodesOnsurface1_2.mat');
    elecmatrix=[elecmatrix;out_els];
end

% Saves all electrodes as one file
outputfile = strcat(['.' filesep name{1} '_electrodes_surface_loc_all.mat']);
save(outputfile,'elecmatrix');


% make a nifti image with electrodes on surface
% use function position2reslicedimage(electrodematrix,anat.nii) to add
% electrodes in one nifti image file
[output,els,els_ind,outputStruct]=position2reslicedImage(elecmatrix);

outputStruct.fname=strcat(['.' filesep name{1} '_electrodes_surface_all.img']);
spm_write_vol(outputStruct,output);

%% 9. Generate Cortex for Visualization
%
% Uses |gen_cortex_click(name, ip_parameter, sm_par)| will create a surface
% of the cortex that you can use to visualize the projected electrodes. You
% need to specify:
%
% * patient ID, if not yet done already (e.g. TWH3#)
% * the gray matter image (e.g. c1TWH#_MR.nii)
% * the white matter image (e.g. c2TWH#_MR.nii)
% * output directory
% * optional: change ip_parameter in the code below (amount of atrophy,
% 0.2-0.4 is generally OK)
% * optional: change sm_par in the code below (amount of smoothing, 1-2 is
% nice)

% Enter subject ID
if exist('name','var') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end

gen_cortex_click_V1(name{1},0.3,2,.98); 

%% 10. Visualize Projected Electrodes
%
% This code uses a couple of CTMR-based and Matlab-based functions for
% plotting the electrodes on the surface. Uncomment as needed.

% load cortex
[data.cortex]=spm_select(1,'mat','select cortex, file format: .mat ');
load([data.cortex])

% load electrodes on surface
[data.electrodeSurface]=spm_select(1,'mat','select files with electrodes on surface, file format: .mat ');
load([data.electrodeSurface])

% plot projected electrodes:
ctmr_gauss_plot(cortex,[0 0 0],0) % generates cortex rendering

% add electrodes in green, size 20. 
el_add(elecmatrix,'g',20);

% add numbers, if desired
%label_add(elecmatrix);

% increase transparency of the cortex
%alpha(0.3)

% adjust view
%loc_view(90,0) %left
%loc_view(270,0) %right

% plot electrodes with nice colors
%r2=[1:length(elecmatrix)];% example value to plot
%max = length(elecmatrix); % maximum for scaling
%el_add_sizable(elecmatrix,r2,max)