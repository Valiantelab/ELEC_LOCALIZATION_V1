
%% 1) Convert DICOM to NIFTII and other housekeeping steps
%  IMPORTANT: For section 1) manually go through the steps. For section 2)
%  do the segmentation of the MR using the GUI. For all other
%  sections, simply run the segment to complete that section. 
%  If BioImageSuite is used to get the coordinates of the electrodes, 
%  skip steps 4 and 5 below.

% 1. Download all CTMR m-files and put them in the same folder.
% 2. Create a folder with the patient's ID
% 3. Startup SPM (spm functions are used)
% 4. Use MRIcron to convert DICOM to NIFTII or use DICOM import on SPM12 
%       for the conversion. 
% 5. Rename and save the NIFTII in a different folder for ease. For the
%       localization, use the MRI and the CT scans that are not prefixed by
%       'o' or 'co'.
% 6. Translate images to the same coordinate space. Can use either SPM or
%       FSL.
% 6a)   Using FSL FLIRT: translate the CT to the same coordinate space as 
%       the MR by doing a linear transformation in FSL FLIRT. 
% 6b)   Using SPM: open the images using Check Reg and set the 
%       crosshairs (right click on image -> Reorient image(s) -> Set origin
%       to crosshairs) to approximately the AC-PC line on the CT scan. 
%       Open them together again to see if both images appear
%       simultanously.
%       If the scans appear to be rotated at an angle of more than 15 
%       degrees from each other, then open them together in SPM using Check 
%       Reg and then rotate one of the images (Right click on image -> 
%       Reorient image(s) -> current image) till they are within 15 degrees 
%       of each other. 
%% 2) Coregister, Reslice, and Segment in SPM:  
% 1. Change the directory path to the folder with the patient's ID 
outputdir = spm_select(1,'dir','select the directory where you want to save all the files');
cd(outputdir)

% 2. Coregister + Reslice CT to anatomical MR in SPM: 
%       In SPM5/SPM8/SPM12 reference image = MR, source/moved image = CT.
%       Changes to default settings are not needed - only specify the two 
%       input niftii files.

spm_coreg

% Select both files for the reslicing. Always select the MR scan first. 
spm_reslice

% 3. Segment anatomical MR in SPM

%% 3) generate surface (The Hull) to project electrodes to

% get_mask_V1(name of file, settings for smoothing and threshold)
% gray matter segmentation probability map, white matter segmentation 
% probability map, output directory will also be needed.  

prompt={'Please enter the subject''s name:'};
title= 'Subject name'; 
name = inputdlg(prompt,title);

get_mask_V1(name{1}, 6,0.1);

% hull is not very nice, because segmentation is not so nice
% Check if the mask nicely surrounds the gray matter in MRICRON or SPM
% Check Reg

%% 4) select electrodes from ct
ctmr
% Look at page 2 in the pdf manual for further instructions on selecting 
% electrodes
% view result
% save image: saves as nifti hdr and img files

%% 5) sort unprojected electrodes
% This step needs to be done separately for each grid or strip.
sortElectrodes;
% loads img file with electrodes from previous step
% saves as electrodes_locX;
% Look at the pdf manual for further instructions on sorting electrodes

%% 6) plot electrodes 2 surface
% electrodes2surf(subject,localnorm index,do not project electrodes closer than 3 mm to surface)

% Grids and strips need to be plotted separately using this step. Code for
% grids, 2XN strips, and 1XN strips is below. Uncomment the code that is
% needed.

% saves automatically a matrix with projected electrode positions and an image
% with projected electrodes

% saves as electrodes_onsurface_filenumber_inputnr2

% [out_els,out_els_ind]=electrodes2surf('name',...
%     5,1,... % use these settings for the grid
%     [1:32],... % electrode numbers from the following file
%     './data/electrodes_loc1.mat',... % file with electrode XYZ coordinates
%     './data/name_surface1_13_02.img',... % surface to which the electrodes are projected
%     './data/t1_aligned.nii');

% Enter subject ID
if exist('name') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end
    

prompt2={'Please enter total number of grids and strips'};
title2= 'Number of electrode configuration'; 
numberOfConfigurations = inputdlg(prompt2,title2);
numberOfConfigurations = str2num(numberOfConfigurations{1})

[data.elecName]=spm_select(1,'mat','select .mat file with electrode positions');
[data.gsName]=spm_select(1,'image','select image with gray matter surface');
[data.mrName]=spm_select(1,'image','select resliced MRI image for electrodes');

for i = 1:numberOfConfigurations
    prompt3={'Please enter 1 for grid, 2 for 2XN strip, 3 for 1xN strip'};
    title3= 'Electrode configuration'; 
    configuration = inputdlg(prompt3,title3);

    prompt4={'Please enter first electrode number in this configuration', 'Please enter last electrode number in this configuration'};
    title4= 'Electrode configuration numbering'; 
    configurationNumber = inputdlg(prompt4,title4);
    
    %surface_name = strcat(surface_name, i);
    
    if configuration{1} == '1'
        [out_els,out_els_ind]=electrodes2surf(name{1},5,1,[str2num(configurationNumber{1}):str2num(configurationNumber{2})], [data.elecName], [data.gsName], [data.mrName]);
    elseif configuration{1} == '2'
        [out_els,out_els_ind]=electrodes2surf(name{1},4,1,[str2num(configurationNumber{1}):str2num(configurationNumber{2})], [data.elecName], [data.gsName], [data.mrName]);
    elseif configuration{1} == '3'
        [out_els,out_els_ind]=electrodes2surf(name{1},0,2,[str2num(configurationNumber{1}):str2num(configurationNumber{2})], [data.elecName], [data.gsName], [data.mrName]);
    end
end


%% 7) combine electrode files into one and make an image

% load all projected electrodes:
% electrodes are saved as out_els

% Enter subject ID
if exist('name') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end

% For the first electrode file
[data.elecName]=spm_select(1,'mat','select .mat first file with electrode positions');
load([data.elecName])

%load('./data/name_electrodesOnsurface1_5.mat');
elecmatrix=out_els;

for i = 1:(numberOfConfigurations - 1)
    % For all additional electrode files
    [data.elecName]=spm_select(1,'mat','select the next .mat file with electrode positions');
    load([data.elecName])

    %load('./data/name_electrodesOnsurface1_2.mat');
    elecmatrix=[elecmatrix;out_els];
end

% Saves all electrodes as one file
outputfile = strcat(['./' name{1} '_electrodes_surface_loc_all.mat'])
save(outputfile,'elecmatrix');


% make a nifti image with electrodes on surface
% use function position2reslicedimage(electrodematrix,anat.nii) to add
% electrodes in one nifti image file
[output,els,els_ind,outputStruct]=position2reslicedImage(elecmatrix);

outputStruct.fname=strcat(['./' name{1} '_electrodes_surface_all.img'])
spm_write_vol(outputStruct,output);

%% 8) generate cortex to render images:

% gen_cortex_click('name',ip_parameter,sm_par)
% ip_parameter reflects amount of atrophy 0.2/0.4 is generally ok
% sm_par reflects the amount of smoothing, 1 or 2 is nice.

% Enter subject ID
if exist('name') == 0
    prompt={'Please enter the subject''s name:'};
    title= 'Subject name'; 
    name = inputdlg(prompt,title);
end

gen_cortex_click_V1(name{1},0.3,2,.98); 

%% 9) plot electrodes on surface 

% load cortex
%load('./data/name_cortex.mat');

[data.cortex]=spm_select(1,'mat','select cortex, file format: .mat ');
load([data.cortex])

% load electrodes on surface
%load('./data/name_electrodes_surface_loc_all1.mat');
[data.electrodeSurface]=spm_select(1,'mat','select files with electrodes on surface, file format: .mat ');
load([data.electrodeSurface])

% plot projected electrodes:
ctmr_gauss_plot(cortex,[0 0 0],0) % generates cortex rendering

% add electrodes in green, size 20. 
el_add(elecmatrix,'g',20);

% or maybe add numbers [Uncomment code below]:
label_add(elecmatrix);

% To increase transparency of the cortex [Uncomment code below]
%alpha(0.3)

% adjust view [Uncomment code below]
%loc_view(90,0) %left
%loc_view(270,0) %right

% plot electrodes with nice colors: [Uncomment code below]
%r2=[1:length(elecmatrix)];% example value to plot
%max = length(elecmatrix); % maximum for scaling
%el_add_sizable(elecmatrix,r2,max)



