% mex -output fastmarch1_mex -cxx -g -I./one2all one2all/y_stand.cpp one2all/my_heap.cpp one2all/unfold.cpp one2all/marchAlg.cpp one2all/io_surface.cpp
mex -output fastmarch_mex  -cxx -g -I./all2all all2all/y_stand.cpp all2all/my_heap.cpp all2all/unfold.cpp all2all/marchAlg.cpp all2all/io_surface.cpp

test_surf = load('michael0');

% All-to-all
D = fastmarch(test_surf.surface.TRIV, test_surf.surface.X, test_surf.surface.Y, test_surf.surface.Z);
trisurf(test_surf.surface.TRIV, test_surf.surface.X, test_surf.surface.Y, test_surf.surface.Z,D(1,:));axis equal; axis tight;

% One-to-all
% source = repmat(Inf, size(test_surf.surface.X));
% source(1) = 0;
% d = fastmarch(test_surf.surface.TRIV, test_surf.surface.X, test_surf.surface.Y, test_surf.surface.Z, source, struct('mode', 'single'));
% trisurf(test_surf.surface.TRIV, test_surf.surface.X, test_surf.surface.Y, test_surf.surface.Z,d);axis equal; axis tight;



