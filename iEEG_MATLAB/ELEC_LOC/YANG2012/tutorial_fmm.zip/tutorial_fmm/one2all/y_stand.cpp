int	XSIZE,YSIZE;	/* The number of vertexes in the x dimension and the y dimenshion of the grid */
int PICSIZE;			/* The total number of vertixes in the grid. */

double **U1,			/* The value of the first parametric axes */
	   **U2,			/* The value of the second parametric axes */
	   **X,	**Y,**Z,	/* The values of the coordinates  of every point in the parametric
						   area. */
	   **X1,**X2,		/* The "nigzeret" of X. 1 is by the first parametric axes and 2 is
						   by the other parametric axes	*/
	   **Y1,**Y2,**Z1,**Z2, /* The same as for x, but for y and z */
	   /* E, F, F, G are the values in the metrix. */
	   **E,				/* The sum of the squres of the partial "nigzert" by u1	*/
	   **F,				/* The sum of the multiplications of the partion "nigzert"s*/
	   **G,				/* Like E but for u2. */
	   **COS,			/* The cos of the the axes in the grid point, used to decide wether to
						   split the triangle. */
	   **sqrtE,**sqrtG; /* The squre roots of the values in E and G.*/

double **sources_dis;	/* The distances between every two sources */

int *BP;				/* The back pointer array of the heap.			   */
